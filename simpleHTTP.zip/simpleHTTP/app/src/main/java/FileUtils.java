import android.graphics.Path;
import android.provider.MediaStore;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class FileUtils {
    public static byte[] loadFiles(String...names) throws IOException {
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream( );
        for ( String name : names ) {
            Path path = Paths.get(  name );
            byte[] data = MediaStore.Files.readAllBytes(path);
            outputStream.write( data );
        }
        return outputStream.toByteArray();
    }

    public static byte[] loadAllCertificates() throws IOException {
        return loadFiles("leaf.der","sub.der");
    }

    public static byte[] loadRootCertificate() throws IOException {
        return loadFiles("root.der");
    }

    public static byte[] loadAllCrl() throws IOException {
        return loadFiles("root.crl","aaica.crl");
    }



}

