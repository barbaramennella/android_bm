import android.os.Build;

import java.io.IOException;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;

import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;

// To enable TLS 1.1 and 1.2 you need to create a custom SSLSocketFactory that is going to proxy
// all calls to a default  SSLSocketFactory implementation

public class TLSSocketFactory extends SSLSocketFactory {

    private SSLSocketFactory internalSSLSocketFactory;

    // alternativo
    // public TLSSocketFactory(SSLSocketFactory delegate) throws KeyManagementException, NoSuchAlgorithmException {
    //  internalSSLSocketFactory = delegate;

    public TLSSocketFactory() throws KeyManagementException, NoSuchAlgorithmException {
        SSLContext context = SSLContext.getInstance ( "TLS" );
        context.init ( null, null, null );

        // modificato da bm
        SSLSocketFactory noSSLv3Factory = null;
        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.JELLY_BEAN_MR2) {
            //noSSLv3Factory = new TLSSocketFactory(context.getSocketFactory()); // nosslv3 creato da questa interfaccia
            internalSSLSocketFactory = context.getSocketFactory ( ); // per ora sono uguali per evitare il null
        } else {
            noSSLv3Factory = context.getSocketFactory ( ); // nosslv3 preso da socketFactory
            internalSSLSocketFactory = context.getSocketFactory ( );
        }
        /// verificare se serve questo protocollo--- connection.setSSLSocketFactory(noSSLv3Factory);
        // fine uso classe
// fine bm

        // vale sopra ---> internalSSLSocketFactory = context.getSocketFactory();
    }

    @Override
    public String[] getDefaultCipherSuites() {
        return internalSSLSocketFactory.getDefaultCipherSuites ( );
    }

    @Override
    public String[] getSupportedCipherSuites() {
        return internalSSLSocketFactory.getSupportedCipherSuites ( );
    }

    @Override
    public Socket createSocket() throws IOException {
        return enableTLSOnSocket ( internalSSLSocketFactory.createSocket ( ) );
    }

    @Override
    public Socket createSocket(Socket s, String host, int port, boolean autoClose) throws IOException {
        return enableTLSOnSocket ( internalSSLSocketFactory.createSocket ( s, host, port, autoClose ) );
    }

    @Override
    public Socket createSocket(String host, int port) throws IOException, UnknownHostException {
        return enableTLSOnSocket ( internalSSLSocketFactory.createSocket ( host, port ) );
    }

    @Override
    public Socket createSocket(String host, int port, InetAddress localHost, int localPort) throws IOException, UnknownHostException {
        return enableTLSOnSocket ( internalSSLSocketFactory.createSocket ( host, port, localHost, localPort ) );
    }

    @Override
    public Socket createSocket(InetAddress host, int port) throws IOException {
        return enableTLSOnSocket ( internalSSLSocketFactory.createSocket ( host, port ) );
    }

    @Override
    public Socket createSocket(InetAddress address, int port, InetAddress localAddress, int localPort) throws IOException {
        return enableTLSOnSocket ( internalSSLSocketFactory.createSocket ( address, port, localAddress, localPort ) );
    }

    private static Socket enableTLSOnSocket(Socket socket) {
        if (socket != null && (socket instanceof SSLSocket)

                && isTLSServerEnabled ( (SSLSocket) socket )) { // togli se il server non fornisce supporto TLS - lato server dovrebbe essere default
            ((SSLSocket) socket).setEnabledProtocols ( new String[]{"TLS_v1_1", "TLS_v1_2"} );
        }
        return socket;
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////
    // gestione server - opzionale
    private static boolean isTLSServerEnabled(SSLSocket sslSocket) {
        String[] protocols = sslSocket.getSupportedProtocols ( );
        System.out.println ( "Supported protocols are:" );
        for (int i = 0; i < protocols.length; i++) {
            System.out.println ( "protocol: " + protocols[i] );
        }
        for (String protocol : sslSocket.getSupportedProtocols ( )) {
            if (protocol.equals ( "TLS_v1_1" ) || protocol.equals ( "TLS_v1_2" )) {
                System.out.println ( "enabled TLS server: " + protocol );
                return true;
            }
        }
        return false;
    }
}



