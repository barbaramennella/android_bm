package com.example.barbara.simplehttp;

import android.graphics.Path;
import android.graphics.drawable.RippleDrawable;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CRL;
import java.security.cert.CRLException;
import java.security.cert.CertPathValidator;
import java.security.cert.CertPathValidatorException;
import java.security.cert.Certificate;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.PKIXParameters;
import java.security.cert.X509Certificate;

import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.GregorianCalendar;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManagerFactory;

import android.app.Activity;
import android.app.DownloadManager;
import android.app.ProgressDialog;
import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import static android.renderscript.Element.DataKind.USER;
import static java.text.AttributedCharacterIterator.Attribute.LANGUAGE;

public class MainActivity extends AppCompatActivity {


    private ProgressDialog progress;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate ( savedInstanceState );
        setContentView ( R.layout.activity_main );
    }

    public void sendPostRequest(View View) {
        new PostClass ( this ).execute ( );
    }

    public void sendGetRequest(View View) {

        new GetClass ( this ).execute ( );
    }

    public void closeRequest(View View) {
        progress.dismiss ( );
    }

    private class PostClass extends AsyncTask<String, Void, Void> {
        private final Context context;

        public PostClass(Context c) {
            this.context = c;
        }

        protected void onPreExecute() {
            /////////////////
            Toast.makeText ( getApplicationContext ( ), "Sto connettendo in POST... ", Toast.LENGTH_LONG ).show ( );
            ////////////////

            progress = new ProgressDialog ( this.context );
            progress.setMessage ( "Loading" );
            progress.show ( );
        }

        @Override
        protected Void doInBackground(String... params) {
            try {

                final TextView outputView = (TextView) findViewById ( R.id.textViewesito );
                 /*
                 TODO ESTENSIONI
                 When you want to load a keystore, you must specify its keystore type. The conventional extensions would be:
                    .jks for type "JKS",
                    .p12 or .pfx for type "PKCS12"
                    In addition, BouncyCastle also provides its implementations, in particular BKS (typically using the .bks extension), which is frequently used for Android applications.
                TODO login
                  //Accetta Credenziali per il log in -- cerca versione api 18 questa è 26
                   String encoded = Base64.getEncoder().encodeToString((userName+":"+userPwd).getBytes(StandardCharsets.UTF_8));
                   connection.setRequestProperty ("Authorization", "Basic "+encoded);
                TODO caricamento del keystore da sistema --- differenza con l'altro metodo
                System.setProperty("javax.net.ssl.keyStore", 'keystoreFile');
                System.setProperty("javax.net.ssl.keyStorePassword", 'keystorePassword ');
                System.setProperty("javax.net.ssl.trustStore", "test.jks");
                System.setProperty("javax.net.ssl.trustStoreType", "jks"); */

                //TODO verifica utilita - HttpsURLConnection.setDefaultSSLSocketFactory(getSocketFactory());
/*
                // TODO Load CAs from an InputStream
                CertificateFactory cf = null; //TODO differenza
                try {
                    cf = CertificateFactory.getInstance("X.509");
                } catch (CertificateException e) {
                    e.printStackTrace ( );
                }
*/
                /*
                // provo da filesystem windows
                InputStream caInput = new BufferedInputStream (new FileInputStream ("BaltimoreCyberTrustRoot.crt")); //TODO differenza
                Certificate ca; //TODO Certificate api 28 trova alternative
                try {
                    try {
                        ca = cf.generateCertificate(caInput);
                        //TODO X509Certificate api 28 trova alternative
                        System.out.println("ca=" + ((X509Certificate) ca).getSubjectDN());
                    } catch (CertificateException e) {
                        e.printStackTrace ( );
                    }
                } finally {
                    caInput.close();
                }
                */

                /*
                //TODO KeyManagerFactory alternativa 1 -  per creare il keymanager usa il tipo di keystore adatto al file chiave PKCS12 ossia SunX509
                KeyManagerFactory keyMgrFactory = KeyManagerFactory.getInstance("SunX509"); //TODO differenza
                KeyStore keyStore = KeyStore.getInstance("PKCS12"); //TODO differenza
                char[] keyStorePassword = pk12Password.toCharArray(); // --> This is the Password for my P12 Client Certificate
                keyStore.load(new FileInputStream(pk12filePath), keyStorePassword); // --> This is the path to my P12 Client Certificate
                keyMgrFactory.init(keyStore, keyStorePassword);


                // TODO KeyManagerFactory alternativa 2 - per creare il keymanager usa il tipo di keystore di default - lo stesso per trustmanager
                String keyStoreType = KeyStore.getDefaultType();
                KeyStore keyStore = null;
                try {
                    keyStore = KeyStore.getInstance(keyStoreType);
                } catch (KeyStoreException e) {
                    e.printStackTrace ( );
                }
                try {
                    keyStore.load(null, null);
                } catch (NoSuchAlgorithmException e) {
                    e.printStackTrace ( );
                } catch (CertificateException e) {
                    e.printStackTrace ( );
                }
                // TODO definire il parametro ca - keyStore.setCertificateEntry("ca", ca);

                /*
                // TODO TrustManagerFactory alternativa 1 - algoritmo specificato
                // Create a trust manager factory for the trust store that contains certificate chains we need to trust
                // our remote server (I have used the default jre/lib/security/cacerts path and password)
                TrustManagerFactory trustStrFactory = TrustManagerFactory.getInstance("SunX509"); //TODO differenza
                KeyStore trustStore = KeyStore.getInstance("JKS");
                //TODO specifica psw - char[] trustStorePassword = jksTrustStorePassword.toCharArray(); // --> This is the Default password for the Java KEystore ("changeit")
                //TODO usa psw - trustStore.load(new FileInputStream(trustStorePath), trustStorePassword);
                trustStore.load(null, null);
                trustStrFactory.init(trustStore);


                // TODO TrustManagerFactory alternativa 2 - algoritmo di default
                String tmfAlgorithm = TrustManagerFactory.getDefaultAlgorithm();
                TrustManagerFactory tmf = null;
                try {
                    tmf = TrustManagerFactory.getInstance(tmfAlgorithm);
                } catch (NoSuchAlgorithmException e) {
                    e.printStackTrace ( );
                }
                try {
                    tmf.init(keyStore);
                } catch (KeyStoreException e) {
                    e.printStackTrace ( );
                }

                // TODO alternativa con forma short -  Make our current SSL context use our customized factories
                //context.init(keyMgrFactory.getKeyManagers(), trustStrFactory.getTrustManagers(), null);

                //Create an SSLContext that uses our TrustManager
                SSLContext context = null;
                try {
                    context = SSLContext.getInstance("TLS");
                } catch (NoSuchAlgorithmException e) {
                    e.printStackTrace ( );
                }

                try {
                    context.init(null, tmf.getTrustManagers(), null);
                } catch (KeyManagementException e) {
                    e.printStackTrace ( );
                }
 */
                // Tell the URLConnection to use a SocketFactory from our SSLContext
               // URL url = new URL ( "https", "certs.cac.washington.edu",
                 //       "CAtest" );

                URL url = new URL ( "https", "it.wikipedia.org", "wiki/Pagina_principale" );
                //URL url = new URL ( "https", "www.google.com", "" );

                HttpsURLConnection connection = (HttpsURLConnection) url.openConnection ( );

               // connection. setSSLSocketFactory(context.getSocketFactory());

                String urlParameters = "cognome=mennella";
                //connection.setRequestMethod ( "POST" ); dipende dal sito se lo accetta google no

                // il default è true settata comunque nel metodo post per indicare l'input nel body
                connection.setDoInput ( true );

                //connection.connect(); con POST alcuni siti lo rifiutano

                // usato per POST
                // DataOutputStream dStream = new DataOutputStream ( connection.getOutputStream ( ) );
                //dStream.writeBytes ( urlParameters );
                //dStream.flush ( );
                //dStream.close ( );

                int responseCode = connection.getResponseCode ( );
                String respmessage = connection.getResponseMessage ();

                Log.i ( "parametri", "name value " + urlParameters );
                Log.i ( "metodo", "metodo di request  " + connection.getRequestMethod ( ) );
                Log.i ( "response", "codice di response  " + responseCode );
                Log.i ( "respmessage", "messaggio di response  " + respmessage  );

                final StringBuilder output = new StringBuilder ( "Request URL " + url );
                output.append ( System.getProperty ( "line.separator" ) + "Parametri di richiesta " + urlParameters );
                output.append ( System.getProperty ( "line.separator" ) + "Codice di risposta " + responseCode );
                output.append ( System.getProperty ( "line.separator" ) + "metodo " + "POST" );

                System.out.println ( "output ==============="  );

                output.append (System.getProperty ( "line.separator" ) +  "output ==============="  );
                BufferedReader br = new BufferedReader ( new InputStreamReader ( connection.getInputStream ( ) ) );

                ///////certificati /////////////////////////
                // La tipica catena è composta da tre certificati: un root (trust anchor), uno intermedio (sub ) e uno foglia (leaf)

                // usato certificate di java....cert --- certificati server
                 Certificate[] certificateS = connection.getServerCertificates ();
                // usato certificate di java...cert. -- certificati locali
                Certificate[] certificateL = connection.getLocalCertificates ();

                System.out.println ( "lunghezza array certificateS " + certificateS.length );

//TODO -- crlsByte valorizzato con il file CRL in formato stream
                InputStream crlsStream = new ByteArrayInputStream ( crlsByte );  //prova a usare get inputstream
                CertificateFactory certFactory = null;
                try {
                    certFactory = CertificateFactory.getInstance("X509");
                } catch (CertificateException e) {
                    e.printStackTrace ( );
                }

                // collezione di liste revoca certificati valorizzata
                // con il file CRL presente nei folder di progetto
                Collection<? extends CRL> crls = null;
                try {
                    crls = certFactory.generateCRLs(crlsStream);
                } catch (CRLException e) {
                    e.printStackTrace ( );
                }
                if (certificateS != null ) {
                    /// ciclo su array liste di revoca certificato
                    for (CRL crl : crls) {
                        ///////////////////////controlli sul certificato corrente in array
                        int x;
                        for (x = 0; x <= certificateS.length; x++) {
                            // issuer - chi ha emesso il certificato

                            // stato revoca
                            if (crl.isRevoked ( certificateS[x] )) {
                                System.out.println ( "Il certificato server non è revocato " + certificateS[x] + " indice " + x + " fine item " );
                            }

                            // issuer - chi ha emesso il certificato
                           //TODO  if (issuer ( certificateS[x] )) {
                                System.out.println ( "L'emittente del certificato server è accettato " + certificateS[x] + " indice " + x + " fine item " );
                            //}

                            // validity - certificato scaduto
                        //TODO  if (outtodate ( certificateS[x] )) {
                             //TODO api 26 - params.setDate( Date.from( LocalDate.of(2017, 1, 1).atStartOfDay().atZone( ZoneId.systemDefault()).toInstant()) );
                            Calendar calendar = new GregorianCalendar();
                            Date trialTime = new Date();
                            calendar.setTime(trialTime);
                            Calendar rightNow = Calendar.getInstance();

                            System.out.println ( "Il certificato server non è scaduto " + certificateS[x] + " indice " + x + " fine item " );
                            //}

                        }// fine ciclo for su lista certificati
                    } // fine ciclo su collezione lista di revoca
                }// se la lista certificati server non è vuota
                // /////////fine certificati /////////////////////////

                output.append ( System.getProperty ( "line.separator" ) + "Response " + System.getProperty ( "line.separator" ) );
                for (String line = br.readLine ( ); line != null; line = br.readLine ( )) {
                    output.append (System.getProperty ( "line.separator" ) +  line ); }
                br.close ( );

                Log.i ( "stepcorrente", "prima di run" );
                ////////////////////////////

                MainActivity.this.runOnUiThread ( new Runnable ( ) {
                    @Override
                    public void run() {
                        outputView.setText ( output );

                        //test certificati
                        //outputView.setText ( output2 );
                        progress.dismiss ( );
                    }
                } );
                connection.disconnect ( );

            } catch (MalformedURLException e) {
                // TODO Auto-generated catch block
                e.getMessage ( );
                System.err.println ( "MalformedURLException " + e.getMessage ( ) ); // esempio di out dell errore
            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace ( );
            }
            //catch (CRLException e) {
              //  // TODO Auto-generated catch block
               // e.printStackTrace ( );
            //}
            return null;
        }

        protected void onPostExecute() {
            progress.dismiss ( );
        }
    } // fine classe postclass

    ////// GET /////////
    private class GetClass extends AsyncTask<String, Void, Void> {
        private final Context context;

        public GetClass(Context c) {
            this.context = c;
        }

        protected void onPreExecute() {

            Toast.makeText ( getApplicationContext ( ), "Sto connettendo in GET... ", Toast.LENGTH_LONG ).show ( );
            progress = new ProgressDialog ( this.context );
            progress.setMessage ( "Loading" );
            progress.show ( );
        }

        @Override
        protected Void doInBackground(String... params) {
            try {
                final TextView outputView = (TextView) findViewById ( R.id.textViewesito );

                URL url = new URL ( "https", "www.google.com",
                        "" );

                HttpsURLConnection connection = (HttpsURLConnection) url.openConnection ( );
                String urlParameters = "nome=barbara";
                connection.setRequestMethod ( "GET" );

                int responseCode = connection.getResponseCode ( );
                System.out.println ( "response code : " + connection.getResponseCode ( ) );

                Log.i ( "parametri", "name value " + urlParameters );
                Log.i ( "metodo", "metodo di request  " + connection.getRequestMethod ( ) );
                Log.i ( "response", "codice di response  " + responseCode );

                final StringBuilder output = new StringBuilder("Request URL " + url);
                output.append ( System.getProperty ( "line.separator" ) + "Parametri di richiesta " + urlParameters );
                output.append ( System.getProperty ( "line.separator" ) + "Codice di risposta " + responseCode );
                output.append ( System.getProperty ( "line.separator" ) + "metodo " + "GET" );

                // stampa un separatore sullo schermo app
                output.append (System.getProperty ( "line.separator" ) +  " output ==============="  );
                BufferedReader br = new BufferedReader(new InputStreamReader(connection.getInputStream()));

                Log.i ( "miaapp", "stream recuperato" );
                output.append ( System.getProperty ( "line.separator" ) + "Response " + System.getProperty ( "line.separator" ) );

                Log.i ( "nomehost", "host " + connection.getURL ( ) );

                for (String line = br.readLine ( ); line != null; line = br.readLine ( )) {
                    output.append (System.getProperty ( "line.separator" ) +  line ); }

                //while ((line = r.readLine ( )) != null) {
                //    output.append ( line );
                //}

                 br.close ( );

                MainActivity.this.runOnUiThread ( new Runnable ( ) {
                    @Override
                    public void run() {
                        outputView.setText ( output );
                        progress.dismiss ( );
                    }
                } );
                // fine runOnUiThread

                // connection.disconnect ( );
            } //finetry

            catch(MalformedURLException e){
                // TODO Auto-generated catch block
                e.printStackTrace ( );
            } catch(IOException e){
                // TODO Auto-generated catch block
                e.printStackTrace ( );
            }

            return null;

        } //dobackground

        protected void onPostExecute () {
            progress.dismiss ( );
        }
    } //classget
}


